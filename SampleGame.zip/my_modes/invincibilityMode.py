import procgame.game
from procgame.game import AdvancedMode

class invincibilityMode(procgame.game.AdvancedMode):
  """
  left chase loop
  """
  def __init__(self, game):
    super(invincibilityMode, self).__init__(game=game,
      priority=11, mode_type=AdvancedMode.Manual) # 11 is the highest so far
    # stuff that gets done EXACTLY once.
    # happens when the "parent" Game creates this mode
    self.game.displayText("Test")
    pass

    def timerCall(self):
        self.game.lamps.standupRightT.disable()
        self.game.lamps.standupRightM.disable()
        self.game.lamps.standupRightB.disable()
        self.game.displayText("invincibilityMode over")
        self.game.modes.remove("invincibility_mode")

    def mode_started(self):
        self.game.displayText("invincibility mode!")
        self.game.score(100000)
        self.delay(name = "next_target",delay = 1,handler=self.timerCall)
        pass
